#include <QCoreApplication>
#include <iostream>
#include <stdlib.h>
#include <string>
#include <fstream>



/***************************************************/
/***************************************************/
/***************************************************/
/***************************************************/
/***************************************************/
/***************************************************/
/***************************************************/
// Classe Joueur


class Joueur{
public:
    std::string nom = "";
    int hp = 50;
    int maxHp = 50;
    int def = 5;
    int att = 5;
    std::string classe = "Guerrier"; // On met une classe par défaut pour les tests

    int argent = 0;
    // Cette stat garde le fait que le joueur garde ou non.
    bool playerBlock = false;
    // Le temps d'effet des compétences du joueur. Sera changée en fonction du combat.
    int playerCntDown = 0;
    int stillAtt = 5; // Valeur de l'attaque qui ne change pas lors des calculs. Sers à retirer le buff d'attaque du guerrier et mage.
    int stillDef = 5;

    // La quantité de poison que le Voleur a accumulé sur son ennemi
    int poison = 0;

    // Inventaire du joueur
    enum Inventory{potion = 10, highPotion = 50}; // Les valeurs sont le montant de soin et les quantites
    Inventory p = potion;
    Inventory P = highPotion;
    int pA = 0; // potion amount
    int PA = 0; // high potion amount


    void save(){ // Fonction d'enregistrement de la partie

        std::string saveNum;

        std::cout << std::string(50, '\n');
        std::cout << "Entrez le numero de la sauvegarde dans lequel vous voulez enregistrer (entre 1 et 9) :" << std::endl << std::endl;

        int choice = -5;

        while (choice <= 0 || choice >= 10){
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            saveNum = "1";
        case 2:
            saveNum = "2";
        case 3:
            saveNum = "3";
        case 4:
            saveNum = "4";
        case 5:
            saveNum = "5";
        case 6:
            saveNum = "6";
        case 7:
            saveNum = "7";
        case 8:
            saveNum = "8";
        case 9:
            saveNum = "9";
        }

        // En C++, les antislash comptent comme une commande. on en met donc 2 pour symboliser l'enregistrement d'un backslash.
        std::string lien = "C:\\Users\\jadsa\\Desktop\\Jad\\Ynov\\Cours\\B2\\C++ Microcontrollers\\Exos\\ProjetFinal\\ProjetFinalRPG\\";

        std::ofstream file_obj;
        // saveNum correspond au numéro de la sauvegarde voulu, de 1 à 9.
        file_obj.open((lien + "Save" + saveNum + ".txt"), std::ios::app); // app pour append, soit écriture

        Joueur j; // création de la classe qui sera insérée dans le fichier.

        j.hp = hp; // On ajuste les infos à enregistrer
        j.maxHp = maxHp;
        j.def = def;
        j.att = att;
        j.classe = classe;
        j.argent = argent;
        j.playerBlock = playerBlock;
        j.playerCntDown = playerCntDown;
        j.stillAtt = stillAtt;
        j.stillDef = stillDef;
        j.poison = 0;

        file_obj.write((char*)&j, sizeof (j)); // on les écrit dans le fichier.



        std::cout << std::string(50, '\n');
        std::cout << "Sauvegarde reussie !" << std::endl << "Entrez 1 pour revenir au jeu, 2 pour revenir au menu et 3 pour quitter :" << std::endl;

        choice = -5;

        while (choice <= 0 || choice >= 4){
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            game(j);
        case 2:
            mainMenu(j);
        case 3:
            exit(1);
        }
    }


    void load(){ // Fonction de chargement d'une partie sauvegardée

        std::string saveNum;

        std::cout << std::string(50, '\n');
        std::cout << "Entrez le numero de la sauvegarde que vous voulez lancer (entre 1 et 9) :" << std::endl << std::endl;

        int choice = -5;

        while (choice <= 0 || choice >= 10){
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            saveNum = "1";
        case 2:
            saveNum = "2";
        case 3:
            saveNum = "3";
        case 4:
            saveNum = "4";
        case 5:
            saveNum = "5";
        case 6:
            saveNum = "6";
        case 7:
            saveNum = "7";
        case 8:
            saveNum = "8";
        case 9:
            saveNum = "9";
        }

        std::string lien = "C:\\Users\\jadsa\\Desktop\\Jad\\Ynov\\Cours\\B2\\C++ Microcontrollers\\Exos\\ProjetFinal\\ProjetFinalRPG\\";

        std::ifstream file_obj;
        file_obj.open((lien + "Save" + saveNum + ".txt"), std::ios::in); // in pour input, soit récupérer l'input du fichier

        Joueur j; // création de la classe qui prendra les infos du fichier.


        file_obj.read((char*)&j, sizeof (j)); // on lis les infos du fichier

        while (!file_obj.eof()){ // tant qu'il y a des infos à récupérer
            hp = j.hp; // On ajuste les infos du joueur à la sauvegarde
            maxHp = j.maxHp;
            def = j.def;
            att = j.att;
            classe = j.classe;
            argent = j.argent;
            playerBlock = j.playerBlock;
            playerCntDown = j.playerCntDown;
            stillAtt = j.stillAtt;
            stillDef = j.stillDef;
            poison = 0;
        }


        game(j);
    }


    void newChar(){ // Toutes les fonctions du code seront dans une classe afin que celles-ci puissent s'appeler entre elles sans soucis.
        std::string input;
        std::cout << "Entrez le nom de votre personnage : " << std::endl << std::endl;
        getline(std::cin, input); // get line est supposé prendre la prochaine ligne entrée par l'utilisateur (séparée par Entrée) mais ne fonctionne pas peu importe la méthode employé (cin et ses equivalents y compris)
        std::cin.clear();
        std::cin.ignore();
        std::cout << std::endl;
        std::cout << "Bienvenue " << input << " !" << std::endl << std::endl;
        nom = input;

        hp = 50; // réinitialisation des stats. Utile si on veut relancer une nouvelle partie depuis un game over par exemple.
        maxHp = 50;
        def = 5;
        stillDef = 5;
        att = 5;
        stillAtt = 5;
        argent = 0;
        poison = 0;
        pA = 0;
        PA = 0;
        playerBlock = false;
        playerCntDown = 0;

        std::cout << std::endl << std::endl << "Choisissez votre classe! 1 pour Guerrier, 2 pour Mage" << std::endl << "3 pour Voleur !" << std::endl;
        int choice = -5;
        while ((choice <= 0) || (choice >= 4)){
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
        }
        std::cout << std::endl;
        switch (choice) {
        case 1:
            classe = "Guerrier";
        case 2:
            classe = "Mage";
        case 3:
            classe = "Voleur";
        }
    }


    // Fonction d'affichage des stats du joueur

    void playerStats(Joueur j){
        std::cout << std::string(50, '\n');
        std::cout << "    Nom:   " << j.nom << std::endl;
        std::cout << " Classe:   " << j.classe << std::endl;
        std::cout << " HP Max:   " << j.maxHp << std::endl;
        std::cout << "     HP:   " << j.hp << std::endl;
        std::cout << "Attaque:   " << j.att << std::endl;
        std::cout << "Defense:   " << j.def << std::endl;
        std::cout << " Argent:   " << j.argent << std::endl << std::endl;

        std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
        int choice = -5;

        while (choice != 1){
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        game(j); // Renvoie le joueur dans le jeu, mais uniquement après qu'il le souhaite et ait analysé ses infos proprement.
    }


    // Boucle du jeu principal

    void game(Joueur j){
        std::cout << std::string(50, '\n'); // Copie 50 retours de ligne. Permet d'afficher un terminal vide quand l'on souhaite.
        std::cout << "Vous pouvez choisir de vous battre contre une multitude d'ennemis differents, ordonnes par difficultee." << std::endl << "Confrontez les comme bon vous semble. A votre aide se trouve une boutique afin de vous procurer d'objets et de vous soigner." << std::endl << "Bonne chance !" << std::endl << std::endl;
        std::cout << "Combats disponibles :" << std::endl << "1: Slime" << std::endl << "2: Goblin" << std::endl << "3: Orc" << std::endl << "4: Dragon" << std::endl << "5: Demon - BOSS" << std::endl << std::endl;
        std::cout << "Autres choix : " << std::endl << "6: Stats" << std::endl << "7: Shop" << std::endl << "8: Quitter"  << std::endl << "9: Sauvegarder"  << std::endl;

        int choice = -5;

        while (choice <= 0 || choice >= 10){
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1: // Les cas 1 à 8 devraient contenir normalement les fonctions combatSlime, ... mais ne sont pas reconnues car les contructeurs sont situés plus tard.
            // Slime
        case 2:
            // Goblin
        case 3:
            // Orc
        case 4:
            // Dragon
        case 5:
            // Démon
        case 6:
            playerStats(j);
        case 7:
            shop(j);
        case 8: // Quitter le jeu
            exit(1);
        case 9:
            save();
        }
    }


    // Boutique

    void shop(Joueur j){
        std::cout << std::string(50, '\n');
        std::cout << "Bienvenue dans la boutique!" << std::endl << "Entrez 1 pour vous soigner - 2 pieces par HP; Entrez 2 pour acheter un objet ou 3 pour revenir au jeu." << std::endl << std::endl;

        int choice = -5;

        while (choice <= 0 || choice >= 4){
            std::cout << "Vous avez " << j.argent << " or" << std::endl;
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            healShop(j);
        case 2:
            itemShop(j);
        case 3:
            game(j);
        }
    }

    // La section qui soigne le joueur dans le shop

    void healShop(Joueur j){
        int healAmount = j.maxHp - (j.maxHp - j.hp);
        int healPrice = healAmount * 2;

        std::cout << "Voulez vous vous soigner pour le prix de " << healPrice << " or?" << std::endl;

        int choice = -5;

        while (choice <= 0 || choice >= 3){
            std::cout << "Veuillez entrer votre choix, 1 pour acheter et 2 pour refuser : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            if(j.argent >= healPrice){
                std::cout << "Merci pour votre achat ! Vous etes soigne !" << std::endl;
                j.hp = j.maxHp;
                j.argent = j.argent - healPrice;
                shop(j);
            }
            else{
                std::cout << "Vous n'avez pas assez d'argent !" << std::endl;
                shop(j);
            }
        case 2:
            shop(j);
        }
    }


    void itemShop(Joueur j){ // La section Objets de la boutique.
        std::cout << std::string(50, '\n');
        std::cout << "Voici le rayon des objets disponibles !" << std::endl << "Entrez 1 pour une potion de soin: 10 HP - 10 or;" << std::endl << "Entrez 2 une grande potion de soin: 50 HP - 100 or" << std::endl << "Entrez 3 pour revenir a la boutique" << std::endl << std::endl;

        int choice = -5;

        while (choice <= 0 || choice >= 4){
            std::cout << "Vous avez " << j.argent << " or" << std::endl;
            std::cout << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            if(j.argent >= 10){
                std::cout << "Merci pour votre achat ! Vous avez gagne une potion !" << std::endl;
                j.pA += 1; // Augmente la quantité de potions du joueur.
                j.argent = j.argent - 10;
                shop(j);
            }
        case 2:
            if(j.argent >= 100){
                std::cout << "Merci pour votre achat ! Vous avez gagne une grande potion !" << std::endl;
                j.PA += 1;
                j.argent = j.argent - 100;
                shop(j);
            }
        case 3:
            shop(j);
        }
    }


    // Instructions du jeu.

    void instructions(Joueur j){
        std::cout << std::string(50, '\n');
        std::cout << "Le jeu consiste a se battre contre divers ennemis et de battre le boss final, le demon." << std::endl << "Pour cela, le joueur peut choisir une des trois classes: Guerrier, Mage et Voleur." << std::endl << std::endl << "Celles-ci donnent des competances differantes mais gardent les memes stats de depart, incitant a une strategie changente." << std::endl;
        std::cout << "Chaque classe possede 4 competances." << std::endl << "Une competance utilisable chaque tour, une competance a effet puissant avec temps de recharge, un moyen de monter sa defence pendant un tour ainsi que sacrifier un tour afin de se soigner." << std::endl << std::endl;
        std::cout << "Le Guerrier possede une competance de base aux degats normaux, ainsi que d'un buff d'attaque durant 5 tours." << std::endl << "C'est une classe equilibree, et puissante mais manquant de moyen facile de se soigner." << std::endl << std::endl;
        std::cout << "Le Mage possede une competance de base de nature moins puissante que celle du guerrier. Cependant son skill d'augmentation d'attaque lui permet de faire bien plus de degats que celui-si, bien que cela soit de temps plus court." << std::endl << "C'est une classe infligant des degats puissants, en sacrifiant la defense et avec un soin remarquable." << std::endl << std::endl;
        std::cout << "Le Voleur possede une competance de base aux degats egaux a ceux du guerrier. Cependant il n'augmente pas son attaque comme celui-ci. Sa deuxieme competance est aussi une attaque, infligant moins de degats mais ajoutant une accumulation permatante de poison sur l'ennemi." << std::endl << "Ce poison aura effet chaque debut de tour - allie ou ennemi - et s'accumule a chaque utilisation." << std::endl << "Le Voleur est donc tres efficace a infliger des degats sur longe periodes, mais possede moins de defense que le guerrier et moins de soin que le mage." << std::endl;
        std::cout << std::endl << "Chaque ennemi donne au joueur une somme fixe d'argent en fonction du type d'ennemi. Cet argent sera utilisable au magasin afin d'acheter des objets utilisables au combat ou se soigner." << std::endl << "Attention! Le joueur n'ayant pas de moyen de fuir le combat, il faut etre attentif et ne pas se ruer sur des ennemis ayant l'air trop puissants." << std::endl << "Le niveau des ennemis n'etant pas explique en avance, vous devrez vous servir de vos propres stats afin de mesurer la difficulte des ennemis a venir." << std::endl << std::endl;
        std::cout << "Ce jeu ne fonctionne pas sous le systeme de niveaux habituels. A la place, le joueur devra monter progressivement ses stats en utilisant ses competances :" << std::endl << "Les competances donneront une amelioration permanante des stats a chaque utilisation." << std::endl << "Exemple: les competances 1 et 2 montent l'attaque joueur tandis que la competance 3 monte la defense et la 4 monte le seuil de vie maximal du joueur." << std::endl << std::endl;
        std::cout << "Bonne chance et profitez bien !" << std::endl << std::endl;

        std::cout << "Choisissez 1 pour jouer, 2 pour revenir au menu et 3 pour quitter !" << std::endl;
        int choice = -5;

        while (choice <= 0 || choice >= 4){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            newChar();
            game(j);
        case 2:
            mainMenu(j);
        case 3:
            exit(1);
        }
    }

    // Menu Principal, première fonction appelée dans le main.

    void mainMenu(Joueur j){
        std::cout << "Bienvenue au RPG!" << std::endl << "Ceci est un RPG suivant des normes de fonctionnement hors de l'habituel." << std::endl << "On vous recommande donc de lire les instructions avant de commencer!" << std::endl << std::endl << "1 pour Jouer, 2 pour les instructions, 3 pour charger une partie,  4 pour quitter :" << std::endl;
        int choice = -5;

        while (choice <= 0 || choice >= 4){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            newChar();
            game(j);
        case 2:
            instructions(j);
        case 3:
            load();
        case 4:
            exit(1);
        }
    }


    // Fonction s'activant lorsque le joueur perd un combat.
    void gameOver(Joueur j){
        std::cout << "Vous etez tombe au combat !" << std::endl << "Game Over !" << std::endl << std::endl;
        std::cout << "Tapez 1 pour revenir au menu, 2 pour relancer une partie ou 3 pour quitter le jeu" << std::endl;
        int choice = -5;

        while (choice <= 0 || choice >= 4){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        switch (choice) {
        case 1:
            mainMenu(j);
        case 2:
            newChar();
            game(j);
        case 3:
            exit(1);
        }
    }

    /***************************************************/
    /***************************************************/
    /***************************************************/
    /***************************************************/
    /***************************************************/
    /***************************************************/
    /***************************************************/
    // Classe Slime


};








class Slime{
public:
    std::string nom = "Slime";
    int hp = 10;
    int def = 2;
    int att = 3;
    int gold = 1;

    void combatSlime(Joueur j, Slime s){
        while (hp > 0 || j.hp > 0){
            std::cout << "Le slime attaque !" << std::endl;
            int damage = att - j.def;
            if (damage <= 0){
                damage = 1;
            }
            std::cout << "Le slime inflige " << damage << " degats a " << j.nom << " !" << std::endl << std::endl;

            j.hp -= damage;

            if (j.hp <= 0){ // Empêche le joueur d'attaquer si il est déjà mort
                break;
            }


            // Si le joueur est un voleur, on vérifie si le poison fait effet avant le tour du joueur.
            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                hp -= j.poison;

                if (hp <= 0){ // Si le poison a vaincu le slime avant le tour du joueur.
                    std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                    j.argent += gold;

                    j.poison = 0;

                    std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                    int choice = -5;

                    // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                    j.def = j.stillDef;

                    while (choice != 1){
                        std::cout << std::endl;
                        std::cin >> choice;
                        std::cin.clear();
                        std::cin.ignore();
                        std::cout << std::endl << std::endl;
                    }

                    j.game(j);
                }
                else{
                    combatSlime(j, s);
                }
            }



            // Lance le tour du joueur en fonction de sa classe.
            if (j.classe == "Guerrier"){
                guerrierTurn(j, s);
            }
            else if (j.classe == "Mage"){
                mageTurn(j, s);
            }
            else if (j.classe == "Voleur"){
                voleurTurn(j, s);
            }
        }

        // Si le joueur gagne, alors il sortira de la fonction avant d'arriver en dehors du while. Il s'agit donc ici de quand j.hp <= 0.
        j.gameOver(j);
    }

    // Fonction qui est appelée au tour du personnage en fonction de sa classe
    void guerrierTurn(Joueur j, Slime s){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Slash - Attaque normale" << std::endl << "2: Warcry - Att +20% (5 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Rest - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){ // Termine le bonus de défense accordé par le block, et donne le bonus de stat à ce moment.
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){ // Si le joueur peut utiliser la compétence de son choix
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 5) && (j.playerCntDown > 0)){ // Si le joueur à une compétence en temps de recharge.
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            guerrierSlash(j, s);
        case 2:
            guerrierWarcry(j, s);
        case 3:
            guerrierGuard(j, s);
        case 4:
            guerrierRest(j, s);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatSlime(j, s);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatSlime(j, s);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void guerrierSlash(Joueur j, Slime s){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le slime pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;
            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatSlime(j, s);
        }
    }

    void guerrierWarcry(Joueur j, Slime s){
        std::cout << "Vous augmentez votre attaque pour 5 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (20/100));
        j.playerCntDown = 5;
        combatSlime(j, s);
    }

    void guerrierGuard(Joueur j, Slime s){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 50/100);
        j.playerBlock = true;
        combatSlime(j, s);
    }

    void guerrierRest(Joueur j, Slime s){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 10/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatSlime(j, s);
    }

    void mageTurn(Joueur j, Slime s){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 5) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            mageFireball(j, s);
        case 2:
            mageBuff(j, s);
        case 3:
            mageGuard(j, s);
        case 4:
            mageHeal(j, s);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatSlime(j, s);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatSlime(j, s);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void mageFireball(Joueur j, Slime s){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le slime pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;
            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatSlime(j, s);
        }
    }

    void mageBuff(Joueur j, Slime s){
        std::cout << "Vous augmentez votre attaque pour 3 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (50/100));
        j.playerCntDown = 3;
        combatSlime(j, s);
    }

    void mageGuard(Joueur j, Slime s){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 30/100);
        j.playerBlock = true;
        combatSlime(j, s);
    }

    void mageHeal(Joueur j, Slime s){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 30/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatSlime(j, s);
    }

    void voleurTurn(Joueur j, Slime s){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }

        while ( (choice <= 0 || choice >= 5)){ // Le voleur n'ayant pas de compétance avec temps de recharge, la condition est simplifiée.
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            voleurSlash(j, s);
        case 2:
            voleurPoisonDagger(j, s);
        case 3:
            voleurGuard(j, s);
        case 4:
            voleurRest(j, s);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }

            combatSlime(j, s);
        case 6:
            if (j.PA > 0){ // Si le joueur à une potion
                j.PA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }


            combatSlime(j, s);
        }
    }

    void voleurSlash(Joueur j, Slime s){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le slime pour " << damage << " degats !" << std::endl;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
            // Le poison ignore les points de défense des ennemis.
            damage += j.poison;
        }

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            // Reinitialisation du poison suite à la victoire
            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatSlime(j, s);
        }
    }

    void voleurPoisonDagger(Joueur j, Slime s){
        int damage = (j.att * 70/100) - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        // Le poison s'accumule aléatoirement, entre 3 et 8 points de dégats par coup.
        j.poison += rand() % 8 + 3;

        std::cout << "Vous attaquez le slime pour " << damage << " degats !" << std::endl;

        std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
        // Le poison ignore les points de défense des ennemis.
        damage += j.poison;

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatSlime(j, s);
        }
    }

    void voleurGuard(Joueur j, Slime s){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 40/100);
        j.playerBlock = true;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatSlime(j, s);
        }

        combatSlime(j, s);
    }

    void voleurRest(Joueur j, Slime s){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 15/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatSlime(j, s);
        }

        combatSlime(j, s);
    }
};


class Goblin{
public:
    std::string nom = "Goblin";
    int hp = 50;
    int def = 10;
    int att = 5;
    int gold = 2;

    void combatGoblin(Joueur j, Goblin g){
        while (hp > 0 || j.hp > 0){
            std::cout << "Le goblin attaque !" << std::endl;
            int damage = att - j.def;
            if (damage <= 0){
                damage = 1;
            }
            std::cout << "Le goblin inflige " << damage << " degats a " << j.nom << " !" << std::endl << std::endl;

            j.hp -= damage;

            if (j.hp <= 0){ // Empêche le joueur d'attaquer si il est déjà mort
                break;
            }


            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le goblin prend " << j.poison << " degats !" << std::endl;
                hp -= j.poison;

                if (hp <= 0){
                    std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
                    j.argent += gold;

                    j.poison = 0;

                    std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                    int choice = -5;

                    // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                    j.def = j.stillDef;

                    while (choice != 1){
                        std::cout << std::endl;
                        std::cin >> choice;
                        std::cin.clear();
                        std::cin.ignore();
                        std::cout << std::endl << std::endl;
                    }

                    j.game(j);
                }
                else{
                    combatGoblin(j, g);
                }
            }


            if (j.classe == "Guerrier"){
                guerrierTurn(j, g);
            }
            else if (j.classe == "Mage"){
                mageTurn(j, g);
            }
            else if (j.classe == "Voleur"){
                voleurTurn(j, g);
            }
        }

        // Si le joueur gagne, alors il sortira de la fonction avant d'arriver en dehors du while. Il s'agit donc ici de quand j.hp <= 0.
        j.gameOver(j);
    }

    // Fonction qui est appelée au tour du personnage en fonction de sa classe
    void guerrierTurn(Joueur j, Goblin g){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Slash - Attaque normale" << std::endl << "2: Warcry - Att +20% (5 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Rest - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 5) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            guerrierSlash(j, g);
        case 2:
            guerrierWarcry(j, g);
        case 3:
            guerrierGuard(j, g);
        case 4:
            guerrierRest(j, g);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatGoblin(j, g);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatGoblin(j, g);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void guerrierSlash(Joueur j, Goblin g){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le goblin pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;
            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatGoblin(j, g);
        }
    }

    void guerrierWarcry(Joueur j, Goblin g){
        std::cout << "Vous augmentez votre attaque pour 5 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (20/100));
        j.playerCntDown = 5;
        combatGoblin(j, g);
    }

    void guerrierGuard(Joueur j, Goblin g){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 50/100);
        j.playerBlock = true;
        combatGoblin(j, g);
    }

    void guerrierRest(Joueur j, Goblin g){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 10/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatGoblin(j, g);
    }

    void mageTurn(Joueur j, Goblin g){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 4) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            mageFireball(j, g);
        case 2:
            mageBuff(j, g);
        case 3:
            mageGuard(j, g);
        case 4:
            mageHeal(j, g);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatGoblin(j, g);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatGoblin(j, g);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void mageFireball(Joueur j, Goblin g){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le goblin pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;
            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatGoblin(j, g);
        }
    }

    void mageBuff(Joueur j, Goblin g){
        std::cout << "Vous augmentez votre attaque pour 3 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (50/100));
        j.playerCntDown = 3;
        combatGoblin(j, g);
    }

    void mageGuard(Joueur j, Goblin g){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 30/100);
        j.playerBlock = true;
        combatGoblin(j, g);
    }

    void mageHeal(Joueur j, Goblin g){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 30/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatGoblin(j, g);
    }

    void voleurTurn(Joueur j, Goblin g){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }

        while ( (choice <= 0 || choice >= 5)){ // Le voleur n'ayant pas de compétance avec temps de recharge, la condition est simplifiée.
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            voleurSlash(j, g);
        case 2:
            voleurPoisonDagger(j, g);
        case 3:
            voleurGuard(j, g);
        case 4:
            voleurRest(j, g);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }

            combatGoblin(j, g);
        case 6:
            if (j.PA > 0){ // Si le joueur à une potion
                j.PA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }


            combatGoblin(j, g);
        }
    }

    void voleurSlash(Joueur j, Goblin g){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le goblin pour " << damage << " degats !" << std::endl;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le goblin prend " << j.poison << " degats !" << std::endl;
            // Le poison ignore les points de défense des ennemis.
            damage += j.poison;
        }

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            // Reinitialisation du poison suite à la victoire
            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatGoblin(j, g);
        }
    }

    void voleurPoisonDagger(Joueur j, Goblin g){
        int damage = (j.att * 70/100) - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        // Le poison s'accumule aléatoirement, entre 3 et 8 points de dégats par coup.
        j.poison += rand() % 8 + 3;

        std::cout << "Vous attaquez le goblin pour " << damage << " degats !" << std::endl;

        std::cout << "Le poison fait effet ! le goblin prend " << j.poison << " degats !" << std::endl;
        // Le poison ignore les points de défense des ennemis.
        damage += j.poison;

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatGoblin(j, g);
        }
    }

    void voleurGuard(Joueur j, Goblin g){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 40/100);
        j.playerBlock = true;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le goblin prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatGoblin(j, g);
        }

        combatGoblin(j, g);
    }

    void voleurRest(Joueur j, Goblin g){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 15/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le goblin prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le goblin ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatGoblin(j, g);
        }

        combatGoblin(j, g);
    }
};


class Orc{
public:
    std::string nom = "Orc";
    int hp = 200;
    int def = 25;
    int att = 15;
    int gold = 20;

    void combatOrc(Joueur j, Orc o){
        while (hp > 0 || j.hp > 0){
            std::cout << "L'orc attaque !" << std::endl;
            int damage = att - j.def;
            if (damage <= 0){
                damage = 1;
            }
            std::cout << "L'orc inflige " << damage << " degats a " << j.nom << " !" << std::endl << std::endl;

            j.hp -= damage;

            if (j.hp <= 0){ // Empêche le joueur d'attaquer si il est déjà mort
                break;
            }


            if (j.poison > 0){
                std::cout << "Le poison fait effet ! l'orc prend " << j.poison << " degats !" << std::endl;
                hp -= j.poison;

                if (hp <= 0){
                    std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
                    j.argent += gold;

                    j.poison = 0;

                    std::cout << "Vous remportez une potion de soin !" << std::endl;

                    j.pA += 1;

                    std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                    int choice = -5;

                    // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                    j.def = j.stillDef;

                    while (choice != 1){
                        std::cout << std::endl;
                        std::cin >> choice;
                        std::cin.clear();
                        std::cin.ignore();
                        std::cout << std::endl << std::endl;
                    }

                    j.game(j);
                }
                else{
                    combatOrc(j, o);
                }
            }


            if (j.classe == "Guerrier"){
                guerrierTurn(j, o);
            }
            else if (j.classe == "Mage"){
                mageTurn(j, o);
            }
            else if (j.classe == "Voleur"){
                voleurTurn(j, o);
            }
        }

        // Si le joueur gagne, alors il sortira de la fonction avant d'arriver en dehors du while. Il s'agit donc ici de quand j.hp <= 0.
        j.gameOver(j);
    }

    // Fonction qui est appelée au tour du personnage en fonction de sa classe
    void guerrierTurn(Joueur j, Orc o){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Slash - Attaque normale" << std::endl << "2: Warcry - Att +20% (5 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Rest - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 5) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            guerrierSlash(j, o);
        case 2:
            guerrierWarcry(j, o);
        case 3:
            guerrierGuard(j, o);
        case 4:
            guerrierRest(j, o);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatOrc(j, o);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatOrc(j, o);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void guerrierSlash(Joueur j, Orc o){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez l'orc pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            std::cout << "Vous remportez une potion de soin !" << std::endl;

            j.pA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatOrc(j, o);
        }
    }

    void guerrierWarcry(Joueur j, Orc o){
        std::cout << "Vous augmentez votre attaque pour 5 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (20/100));
        j.playerCntDown = 5;
        combatOrc(j, o);
    }

    void guerrierGuard(Joueur j, Orc o){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 50/100);
        j.playerBlock = true;
        combatOrc(j, o);
    }

    void guerrierRest(Joueur j, Orc o){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 10/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatOrc(j, o);
    }

    void mageTurn(Joueur j, Orc o){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 4) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            mageFireball(j, o);
        case 2:
            mageBuff(j, o);
        case 3:
            mageGuard(j, o);
        case 4:
            mageHeal(j, o);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatOrc(j, o);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatOrc(j, o);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void mageFireball(Joueur j, Orc o){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez l'orc pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            std::cout << "Vous remportez une potion de soin !" << std::endl;

            j.pA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatOrc(j, o);
        }
    }

    void mageBuff(Joueur j, Orc o){
        std::cout << "Vous augmentez votre attaque pour 3 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (50/100));
        j.playerCntDown = 3;
        combatOrc(j, o);
    }

    void mageGuard(Joueur j, Orc o){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 30/100);
        j.playerBlock = true;
        combatOrc(j, o);
    }

    void mageHeal(Joueur j, Orc o){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 30/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatOrc(j, o);
    }

    void voleurTurn(Joueur j, Orc o){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }

        while ( (choice <= 0 || choice >= 5)){ // Le voleur n'ayant pas de compétance avec temps de recharge, la condition est simplifiée.
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            voleurSlash(j, o);
        case 2:
            voleurPoisonDagger(j, o);
        case 3:
            voleurGuard(j, o);
        case 4:
            voleurRest(j, o);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }

            combatOrc(j, o);
        case 6:
            if (j.PA > 0){ // Si le joueur à une potion
                j.PA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }


            combatOrc(j, o);
        }
    }

    void voleurSlash(Joueur j, Orc o){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez l'orc pour " << damage << " degats !" << std::endl;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! l'orc prend " << j.poison << " degats !" << std::endl;
            // Le poison ignore les points de défense des ennemis.
            damage += j.poison;
        }

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            // Reinitialisation du poison suite à la victoire
            j.poison = 0;

            std::cout << "Vous remportez une potion de soin !" << std::endl;

            j.pA += 1;


            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatOrc(j, o);
        }
    }

    void voleurPoisonDagger(Joueur j, Orc o){
        int damage = (j.att * 70/100) - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        // Le poison s'accumule aléatoirement, entre 3 et 8 points de dégats par coup.
        j.poison += rand() % 8 + 3;

        std::cout << "Vous attaquez l'orc pour " << damage << " degats !" << std::endl;

        std::cout << "Le poison fait effet ! l'orc prend " << j.poison << " degats !" << std::endl;
        // Le poison ignore les points de défense des ennemis.
        damage += j.poison;

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;


            std::cout << "Vous remportez une potion de soin !" << std::endl;

            j.pA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatOrc(j, o);
        }
    }

    void voleurGuard(Joueur j, Orc o){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 40/100);
        j.playerBlock = true;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! l'orc prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;


            std::cout << "Vous remportez une potion de soin !" << std::endl;

            j.pA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatOrc(j, o);
        }

        combatOrc(j, o);
    }

    void voleurRest(Joueur j, Orc o){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 15/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! l'orc prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu l'orc ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;


            std::cout << "Vous remportez une potion de soin !" << std::endl;

            j.pA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatOrc(j, o);
        }

        combatOrc(j, o);
    }
};


class Dragon{
public:
    std::string nom = "Dragon";
    int hp = 5000;
    int def = 100;
    int att = 50;
    int gold = 1000;

    void combatDragon(Joueur j, Dragon d){
        while (hp > 0 || j.hp > 0){
            std::cout << "Le dragon attaque !" << std::endl;
            int damage = att - j.def;
            if (damage <= 0){
                damage = 1;
            }
            std::cout << "Le dragon inflige " << damage << " degats a " << j.nom << " !" << std::endl << std::endl;

            j.hp -= damage;

            if (j.hp <= 0){ // Empêche le joueur d'attaquer si il est déjà mort
                break;
            }


            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le dragon prend " << j.poison << " degats !" << std::endl;
                hp -= j.poison;

                if (hp <= 0){
                    std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
                    j.argent += gold;

                    j.poison = 0;


                    std::cout << "Vous remportez une grande potion de soin !" << std::endl;

                    j.PA += 1;

                    std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                    int choice = -5;

                    // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                    j.def = j.stillDef;

                    while (choice != 1){
                        std::cout << std::endl;
                        std::cin >> choice;
                        std::cin.clear();
                        std::cin.ignore();
                        std::cout << std::endl << std::endl;
                    }

                    j.game(j);
                }
                else{
                    combatDragon(j, d);
                }
            }


            if (j.classe == "Guerrier"){
                guerrierTurn(j, d);
            }
            else if (j.classe == "Mage"){
                mageTurn(j, d);
            }
            else if (j.classe == "Voleur"){
                voleurTurn(j, d);
            }
        }

        // Si le joueur gagne, alors il sortira de la fonction avant d'arriver en dehors du while. Il s'agit donc ici de quand j.hp <= 0.
        j.gameOver(j);
    }

    // Fonction qui est appelée au tour du personnage en fonction de sa classe
    void guerrierTurn(Joueur j, Dragon d){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Slash - Attaque normale" << std::endl << "2: Warcry - Att +20% (5 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Rest - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 4) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            guerrierSlash(j, d);
        case 2:
            guerrierWarcry(j, d);
        case 3:
            guerrierGuard(j, d);
        case 4:
            guerrierRest(j, d);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDragon(j, d);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDragon(j, d);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void guerrierSlash(Joueur j, Dragon d){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le dragon pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;


            std::cout << "Vous remportez une grande potion de soin !" << std::endl;

            j.PA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDragon(j, d);
        }
    }

    void guerrierWarcry(Joueur j, Dragon d){
        std::cout << "Vous augmentez votre attaque pour 5 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (20/100));
        j.playerCntDown = 5;
        combatDragon(j, d);
    }

    void guerrierGuard(Joueur j, Dragon d){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 50/100);
        j.playerBlock = true;
        combatDragon(j, d);
    }

    void guerrierRest(Joueur j, Dragon d){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 10/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatDragon(j, d);
    }

    void mageTurn(Joueur j, Dragon d){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 4) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            mageFireball(j, d);
        case 2:
            mageBuff(j, d);
        case 3:
            mageGuard(j, d);
        case 4:
            mageHeal(j, d);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDragon(j, d);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDragon(j, d);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void mageFireball(Joueur j, Dragon d){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le dragon pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            std::cout << "Vous remportez une grande potion de soin !" << std::endl;

            j.PA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDragon(j, d);
        }
    }

    void mageBuff(Joueur j, Dragon d){
        std::cout << "Vous augmentez votre attaque pour 3 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (50/100));
        j.playerCntDown = 3;
        combatDragon(j, d);
    }

    void mageGuard(Joueur j, Dragon d){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 30/100);
        j.playerBlock = true;
        combatDragon(j, d);
    }

    void mageHeal(Joueur j, Dragon d){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 30/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatDragon(j, d);
    }

    void voleurTurn(Joueur j, Dragon d){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }

        while ( (choice <= 0 || choice >= 5)){ // Le voleur n'ayant pas de compétance avec temps de recharge, la condition est simplifiée.
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            voleurSlash(j, d);
        case 2:
            voleurPoisonDagger(j, d);
        case 3:
            voleurGuard(j, d);
        case 4:
            voleurRest(j, d);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }

            combatDragon(j, d);
        case 6:
            if (j.PA > 0){ // Si le joueur à une potion
                j.PA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le slime prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            hp -= j.poison;
            if (hp <= 0){
                std::cout << "Vous avez vaincu le slime ! Vous remportez " << gold << " or!" << std::endl;
                j.argent += gold;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }


            combatDragon(j, d);
        }
    }

    void voleurSlash(Joueur j, Dragon d){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le dragon pour " << damage << " degats !" << std::endl;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le dragon prend " << j.poison << " degats !" << std::endl;
            // Le poison ignore les points de défense des ennemis.
            damage += j.poison;
        }

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            // Reinitialisation du poison suite à la victoire
            j.poison = 0;


            std::cout << "Vous remportez une grande potion de soin !" << std::endl;

            j.PA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDragon(j, d);
        }
    }

    void voleurPoisonDagger(Joueur j, Dragon d){
        int damage = (j.att * 70/100) - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        // Le poison s'accumule aléatoirement, entre 3 et 8 points de dégats par coup.
        j.poison += rand() % 8 + 3;

        std::cout << "Vous attaquez le dragon pour " << damage << " degats !" << std::endl;

        std::cout << "Le poison fait effet ! le dragon prend " << j.poison << " degats !" << std::endl;
        // Le poison ignore les points de défense des ennemis.
        damage += j.poison;

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;


            std::cout << "Vous remportez une grande potion de soin !" << std::endl;

            j.PA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDragon(j, d);
        }
    }

    void voleurGuard(Joueur j, Dragon d){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 40/100);
        j.playerBlock = true;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le dragon prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;


            std::cout << "Vous remportez une grande potion de soin !" << std::endl;

            j.PA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDragon(j, d);
        }

        combatDragon(j, d);
    }

    void voleurRest(Joueur j, Dragon d){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 15/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le dragon prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le dragon ! Vous remportez " << gold << " or!" << std::endl;
            j.argent += gold;

            j.poison = 0;


            std::cout << "Vous remportez une grande potion de soin !" << std::endl;

            j.PA += 1;

            std::cout << "Entrez 1 pour revenir au jeu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDragon(j, d);
        }

        combatDragon(j, d);
    }
};




class Demon{
public:
    std::string nom = "Dragon";
    int hp = 7000;
    int def = 200;
    int att = 100;

    void combatDemon(Joueur j, Demon d){
        while (hp > 0 || j.hp > 0){
            std::cout << "Le demon attaque !" << std::endl;
            int damage = att - j.def;
            if (damage <= 0){
                damage = 1;
            }
            std::cout << "Le demon inflige " << damage << " degats a " << j.nom << " !" << std::endl << std::endl;

            j.hp -= damage;

            if (j.hp <= 0){ // Empêche le joueur d'attaquer si il est déjà mort
                break;
            }


            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le dragon prend " << j.poison << " degats !" << std::endl;
                hp -= j.poison;

                if (hp <= 0){
                    std::cout << "Vous avez vaincu le dragon ! Felicitations !"<< std::endl;

                    j.poison = 0;

                    std::cout << "Entrez 1 pour revenir menu :" << std::endl;
                    int choice = -5;

                    // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                    j.def = j.stillDef;

                    while (choice != 1){
                        std::cout << std::endl;
                        std::cin >> choice;
                        std::cin.clear();
                        std::cin.ignore();
                        std::cout << std::endl << std::endl;
                    }

                    j.mainMenu(j);
                }
                else{
                    combatDemon(j, d);
                }
            }


            if (j.classe == "Guerrier"){
                guerrierTurn(j, d);
            }
            else if (j.classe == "Mage"){
                mageTurn(j, d);
            }
            else if (j.classe == "Voleur"){
                voleurTurn(j, d);
            }
        }

        // Si le joueur gagne, alors il sortira de la fonction avant d'arriver en dehors du while. Il s'agit donc ici de quand j.hp <= 0.
        j.gameOver(j);
    }

    // Fonction qui est appelée au tour du personnage en fonction de sa classe
    void guerrierTurn(Joueur j, Demon d){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Slash - Attaque normale" << std::endl << "2: Warcry - Att +20% (5 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Rest - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 4) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            guerrierSlash(j, d);
        case 2:
            guerrierWarcry(j, d);
        case 3:
            guerrierGuard(j, d);
        case 4:
            guerrierRest(j, d);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDemon(j, d);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDemon(j, d);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void guerrierSlash(Joueur j, Demon d){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le demon pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;
            std::cout << "Entrez 1 pour revenir au menu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.mainMenu(j);
        }
        else{
            combatDemon(j, d);
        }
    }

    void guerrierWarcry(Joueur j, Demon d){
        std::cout << "Vous augmentez votre attaque pour 5 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (20/100));
        j.playerCntDown = 5;
        combatDemon(j, d);
    }

    void guerrierGuard(Joueur j, Demon d){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 50/100);
        j.playerBlock = true;
        combatDemon(j, d);
    }

    void guerrierRest(Joueur j, Demon d){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 10/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatDemon(j, d);
    }

    void mageTurn(Joueur j, Demon d){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }


        while ( (choice <= 0 || choice >= 5) && (j.playerCntDown <= 0)){
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }
        while ((choice <= 0 || choice >= 2) && (choice <= 0 || choice >= 4) && (j.playerCntDown > 0)){
            std::cout << "Veuillez entrer votre choix (votre skill 2 est en cooldown): " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            mageFireball(j, d);
        case 2:
            mageBuff(j, d);
        case 3:
            mageGuard(j, d);
        case 4:
            mageHeal(j, d);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDemon(j, d);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            combatDemon(j, d);
        }

        if (j.playerCntDown > 0){
            if (j.playerCntDown == 1){ // dans le cas où l'effet s'en va, on retire le bonus d'attaque.
                j.playerCntDown -= 1;
                j.att = j.stillAtt;
                j.att += 2;
                j.stillAtt += 2;
            }
            else{
                j.playerCntDown -= 1;
            }
        }
    }

    void mageFireball(Joueur j, Demon d){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le demon pour " << damage << " degats !" << std::endl;
        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;
            std::cout << "Entrez 1 pour revenir au menu :" << std::endl;
            int choice = -5;

            j.att = j.stillAtt; // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDemon(j, d);
        }
    }

    void mageBuff(Joueur j, Demon d){
        std::cout << "Vous augmentez votre attaque pour 3 tours !" << std::endl << std::endl;
        j.att += round(j.stillAtt * (50/100));
        j.playerCntDown = 3;
        combatDemon(j, d);
    }

    void mageGuard(Joueur j, Demon d){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 30/100);
        j.playerBlock = true;
        combatDemon(j, d);
    }

    void mageHeal(Joueur j, Demon d){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 30/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;
        combatDemon(j, d);
    }

    void voleurTurn(Joueur j, Demon d){
        std::cout << "Votre tour !" << std::endl << std::endl << "1: Fireball - Attaque normale" << std::endl << "2: Buff - Att +50% (3 tours)" << std::endl << "3: Block - +50% Def" << std::endl << "4: Heal - se soigner" << std::endl << "5: potion de soin - 10 HP" << std::endl << "6: grande potion de soin - 50 HP" << std::endl << std::endl;
        int choice = -5;

        if (j.playerBlock == true){
            j.playerBlock = false;
            j.def = j.stillDef;
            j.def += 1;
            j.stillDef += 1;
        }

        while ( (choice <= 0 || choice >= 5)){ // Le voleur n'ayant pas de compétance avec temps de recharge, la condition est simplifiée.
            std::cout << "Veuillez entrer votre choix : " << std::endl;
            std::cin >> choice;
            std::cin.clear();
            std::cin.ignore();
            std::cout << std::endl << std::endl;
        }

        switch (choice) {
        case 1:
            voleurSlash(j, d);
        case 2:
            voleurPoisonDagger(j, d);
        case 3:
            voleurGuard(j, d);
        case 4:
            voleurRest(j, d);
        case 5:
            if (j.pA > 0){ // Si le joueur à une potion
                j.pA -= 1; // Retire une potion de l'inventaire du joueur
                j.hp += j.p;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{ // Si le joueur n'a pas de potion
                std::cout << "Vous n'avez pas de potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le demon prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            if (hp <= 0){
                std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au menu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }

            combatDemon(j, d);
        case 6:
            if (j.PA > 0){
                j.PA -= 1;
                j.hp += j.P;
                if (j.hp > j.maxHp){
                    j.hp = j.maxHp;
                }
                std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            }
            else{
                std::cout << "Vous n'avez pas de grande potion ! Le temps de chercher une potion vous a couté votre tour !" << std::endl;
            }

            if (j.poison > 0){
                std::cout << "Le poison fait effet ! le demon prend " << j.poison << " degats !" << std::endl;
                // Le poison ignore les points de défense des ennemis.
                hp -= j.poison;
            }

            if (hp <= 0){
                std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;

                // Reinitialisation du poison suite à la victoire
                j.poison = 0;

                std::cout << "Entrez 1 pour revenir au menu :" << std::endl;
                int choice = -5;

                // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
                j.def = j.stillDef;

                while (choice != 1){
                    std::cout << std::endl;
                    std::cin >> choice;
                    std::cin.clear();
                    std::cin.ignore();
                    std::cout << std::endl << std::endl;
                }

                j.game(j);
            }

            std::cout << "Vous utilisez une grande potion de soin !" << std::endl << "Vous avez " << j.hp << " HP !" << std::endl;
            combatDemon(j, d);
        }
    }

    void voleurSlash(Joueur j, Demon d){
        int damage = j.att - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        std::cout << "Vous attaquez le demon pour " << damage << " degats !" << std::endl;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le demon prend " << j.poison << " degats !" << std::endl;
            // Le poison ignore les points de défense des ennemis.
            damage += j.poison;
        }

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;

            // Reinitialisation du poison suite à la victoire
            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au menu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDemon(j, d);
        }
    }

    void voleurPoisonDagger(Joueur j, Demon d){
        int damage = (j.att * 70/100) - def;
        if (damage <= 0){
            damage = 1;
        }
        j.att += 1;
        j.stillAtt += 1;

        // Le poison s'accumule aléatoirement, entre 3 et 8 points de dégats par coup.
        j.poison += rand() % 8 + 3;

        std::cout << "Vous attaquez le demon pour " << damage << " degats !" << std::endl;

        std::cout << "Le poison fait effet ! le demon prend " << j.poison << " degats !" << std::endl;
        // Le poison ignore les points de défense des ennemis.
        damage += j.poison;

        hp -= damage;
        if (hp <= 0){
            std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir au menu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDemon(j, d);
        }
    }

    void voleurGuard(Joueur j, Demon d){
        std::cout << "Vous augmentez votre defense durant ce tour !" << std::endl << std::endl;
        j.def += round(j.stillDef * 40/100);
        j.playerBlock = true;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le demon prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le demon ! Felicitations" << std::endl;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir menu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDemon(j, d);
        }

        combatDemon(j, d);
    }

    void voleurRest(Joueur j, Demon d){
        std::cout << "Vous vous soignez durant ce tour !" << std::endl << std::endl;
        j.hp += round(j.maxHp * 15/100);
        if (j.hp > j.maxHp){
            j.hp = j.maxHp;
        }
        j.hp += 1;
        j.maxHp += 1;

        if (j.poison > 0){
            std::cout << "Le poison fait effet ! le demon prend " << j.poison << " degats !" << std::endl;
            hp -= j.poison;
        }

        if (hp <= 0){
            std::cout << "Vous avez vaincu le demon ! Felicitations !" << std::endl;

            j.poison = 0;

            std::cout << "Entrez 1 pour revenir menu :" << std::endl;
            int choice = -5;

            // retour des valeurs à la normale si elles ont étées altérées avant la fin du combat.
            j.def = j.stillDef;

            while (choice != 1){
                std::cout << std::endl;
                std::cin >> choice;
                std::cin.clear();
                std::cin.ignore();
                std::cout << std::endl << std::endl;
            }

            j.game(j);
        }
        else{
            combatDemon(j, d);
        }

        combatDemon(j, d);
    }
};


int main()
{
    Joueur j;

    // Menu principal, qui mène au lancement du jeu en entier
    j.mainMenu(j);
}



